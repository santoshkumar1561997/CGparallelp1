package com.cg.skwallet.exception;

public class WalletException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	String message;
	public WalletException() {
		// TODO Auto-generated constructor stub
	}
	public WalletException(String message) {
		super(message);
		//this.message = message;
	}
}
