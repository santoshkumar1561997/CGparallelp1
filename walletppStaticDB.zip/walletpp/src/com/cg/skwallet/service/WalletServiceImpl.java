package com.cg.skwallet.service;

import com.cg.skwallet.bean.WalletAccount;
import com.cg.skwallet.bean.WalletTransaction;
import com.cg.skwallet.dao.WalletDAO;
import com.cg.skwallet.dao.WalletDAOImpl;
import com.cg.skwallet.exception.WalletException;

import java.util.*;

public class WalletServiceImpl implements WalletService {
	WalletDAO dao=new WalletDAOImpl();
	public WalletServiceImpl() {
		// TODO Auto-generated constructor stub
	}

	@Override
	public WalletAccount createAccount(WalletAccount acc)throws WalletException {
		// TODO Auto-generated method stub
		return dao.createAccount(acc);
	}

	@Override
	public double showBalance(String username,String password) throws WalletException {
		// TODO Auto-generated method stub
		return dao.showBalance(username,password);
	}

	@Override
	public WalletAccount deposit(String username,double amount) throws WalletException {
		// TODO Auto-generated method stub
		return dao.deposit(username, amount);
	}

	@Override
	public WalletAccount withdraw(String username,String password, double amount) throws WalletException {
		// TODO Auto-generated method stub
		return dao.withdraw(username,password, amount);
	}

	@Override
	public boolean fundTransfer(String fromUserName,String fromPassword,String toUserName,double amount)throws WalletException  {
		// TODO Auto-generated method stub
		return dao.fundTransfer(fromUserName,fromPassword, toUserName,amount);
	}

	@Override
	public List<WalletTransaction> printTransactions(String username,String password) throws WalletException {
		// TODO Auto-generated method stub
		return dao.printTransactions(username,password);
	}
}
