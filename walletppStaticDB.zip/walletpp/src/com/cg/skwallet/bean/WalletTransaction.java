package com.cg.skwallet.bean;

import java.util.Date;

public class WalletTransaction {
	private String userName;
	private String type;
	private double amount;
	private double fbalance;
	private Date d;
	public WalletTransaction(String userName, String type, double amount,
			double fbalance,Date d) {
		super();
		this.setUserName(userName);
		this.type = type;
		this.amount = amount;
		this.fbalance = fbalance;
		this.d=d;
	}
	@Override
	public String toString() {
		return "\n" + type
				+ "    |    " + amount + " : " + fbalance + "  |    " + d
				+ " ";
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	
		
	

}
