package com.cg.skwallet.db;

import java.util.*;

import com.cg.skwallet.bean.WalletAccount;
import com.cg.skwallet.bean.WalletTransaction;
public class StaticDB {
	private static HashMap<String, WalletAccount> wMap=new HashMap<String, WalletAccount>();
	private static HashMap<String, List<WalletTransaction>> tMap=new HashMap<String,List<WalletTransaction>>();
	
	static
	{ /*Date d = new Date();
		wMap.put("sk1",new WalletAccount("sk1",0,"sk@1"));
		wMap.put("sk2",new WalletAccount("sk2",0,"sk@2"));
		tMap.put("sk1",new ArrayList<WalletTransaction>());
		tMap.put("sk2",new ArrayList<WalletTransaction>());
		tMap.get("sk1").add(new WalletTransaction("sk1", "Deposit",1000.0 , 1000,d));
		wMap.get("sk1").setBalance(1000);
		tMap.get("sk1").add(new WalletTransaction("sk1", "Withdraw",500 , 500,d));
		wMap.get("sk1").setBalance(500);
		tMap.get("sk1").add(new WalletTransaction("sk1", "Transfer(debit)",250 , 250,d ));
		tMap.get("sk2").add(new WalletTransaction("sk2", "Transfer(credit)",250 , 250,d ));
		wMap.get("sk1").setBalance(250);
		wMap.get("sk2").setBalance(250);*/
	}
	public static HashMap<String, WalletAccount> getWMap()
	{
		return wMap;
	}
	
	public static HashMap<String,List<WalletTransaction>> getTMap()
	{  //System.out.println(tMap);
		return tMap;
	}

}
