/**
 * 
 */
package com.cg.skwallet.test;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.cg.skwallet.bean.WalletAccount;
import com.cg.skwallet.dao.WalletDAO;
import com.cg.skwallet.dao.WalletDAOImpl;
import com.cg.skwallet.exception.WalletException;

/**
 * @author skuma661
 *
 */
public class TestDAO {

	/**
	 * @throws java.lang.Exception
	 */
	WalletDAO dao;
	WalletAccount wa;
	@Before
	public void setUp() throws Exception {
		dao=new WalletDAOImpl();
		wa=new WalletAccount("ak",0, "ak");

	}

	/**
	 * @throws java.lang.Exception
	 */
	@After
	public void tearDown() throws Exception {
	dao=null;
	wa=null;
	}

	@Test
	public void testCreateAccount() throws WalletException {
		assertEquals(wa,dao.createAccount(wa));
	}

	/*@Test
	public void testShowBalance() throws WalletException {
		assertEquals(wa.getBalance(),dao.showBalance(wa.getUserName(), wa.getPassword()));
	}*/
	

}
