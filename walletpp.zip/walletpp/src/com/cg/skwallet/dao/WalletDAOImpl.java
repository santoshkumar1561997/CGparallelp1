package com.cg.skwallet.dao;

import com.cg.skwallet.bean.WalletAccount;
import com.cg.skwallet.bean.WalletTransaction;
import com.cg.skwallet.db.StaticDB;
import com.cg.skwallet.exception.WalletException;

import java.time.LocalDateTime;
import java.util.*;

public class WalletDAOImpl implements WalletDAO{
	
	@Override
	public WalletAccount createAccount(WalletAccount acc) throws WalletException {
		// TODO Auto-generated method stub
		if(StaticDB.getWMap().containsKey(acc.getUserName()))
			throw new WalletException("Username exists Already");
		else
		{		StaticDB.getWMap().put(acc.getUserName(), acc);
				StaticDB.getTMap().put(acc.getUserName(),new ArrayList<WalletTransaction>());			
				StaticDB.getTMap().get(acc.getUserName()).add(new WalletTransaction(acc.getUserName(),"Created",acc.getBalance(),acc.getBalance(),LocalDateTime.now()));
		}
		return acc;
	}

	@Override
	public double showBalance(String username,String password)  throws WalletException {
		// TODO Auto-generated method stub
		if(validateUser(username, password))
		 return StaticDB.getWMap().get(username).getBalance();
		
		return 0;
	}

	@Override
	public WalletAccount deposit(String username, double amount) throws WalletException  {
		// TODO Auto-generated method stub
		if(!StaticDB.getWMap().containsKey(username))
			throw new WalletException("Username incorrect,No such account exist");
		else
		{
			StaticDB.getWMap().get(username).setBalance(StaticDB.getWMap().get(username).getBalance()+amount);
			double fbalance =StaticDB.getWMap().get(username).getBalance()+amount;
			StaticDB.getTMap().get(username).add(new WalletTransaction(username, "Deposit", amount, fbalance, LocalDateTime.now()));
			return StaticDB.getWMap().get(username);
		}	
	}

	@Override
	public WalletAccount withdraw(String username,String password, double amount)  throws WalletException {
		// TODO Auto-generated method stub
		double balance=StaticDB.getWMap().get(username).getBalance();
			if(!StaticDB.getWMap().containsKey(username))
				throw new WalletException("Username incorrect,No such account exist");
			else if(!StaticDB.getWMap().get(username).getPassword().equals(password))
				throw new WalletException("Wrong Password!! Access Denied");
			else
				if(balance-amount>=0)
					throw new WalletException("Insufficient Balance");
				else
				{
					StaticDB.getWMap().get(username).setBalance(balance-amount);
					double fbalance =StaticDB.getWMap().get(username).getBalance()-amount;
					StaticDB.getTMap().get(username).add(new WalletTransaction(username, "Withdraw", amount, fbalance, LocalDateTime.now()));
					return StaticDB.getWMap().get(username);
				}
	}

	@Override
	public List<WalletAccount> fundTransfer(String fromUserName,String fromPassword,String toUserName,double amount) throws WalletException  {
		// TODO Auto-generated method stub
		if(validateUser(fromUserName, fromPassword));
		else if(!StaticDB.getWMap().containsKey(toUserName))
			throw new WalletException("Invalid Receiver,No such account exist");
		else
		{
			withdraw(fromUserName,fromPassword, amount);
			double fbalance =StaticDB.getWMap().get(fromUserName).getBalance()-amount;
			deposit(toUserName, amount);
			double fbalance1 =StaticDB.getWMap().get(toUserName).getBalance()+amount;
			StaticDB.getTMap().get(fromUserName).add(new WalletTransaction(fromUserName, "Transfer to  ", amount, fbalance, LocalDateTime.now()));
			StaticDB.getTMap().get(fromUserName).add(new WalletTransaction(toUserName, "Get By Transfer ", amount, fbalance1, LocalDateTime.now()));
			List<WalletAccount> wList=new ArrayList<WalletAccount>();
			wList.add(StaticDB.getWMap().get(fromUserName));
			wList.add(StaticDB.getWMap().get(toUserName));
			return wList;
		}
		return null;
	}

	@Override
	public List<WalletTransaction> printTransactions(String username,String password) throws WalletException  {
		// TODO Auto-generated method stub
		//Map<String ,List<WalletTransaction>> temp=new HashMap<String,List< WalletTransaction>>(StaticDB.getTMap());
		
		List<WalletTransaction> li=new ArrayList<WalletTransaction>(StaticDB.getTMap().getOrDefault(username, new ArrayList<WalletTransaction>()));
		//System.out.println(li);
		if(validateUser(username, password))
		{	return li;
			}
		else 
			return null;
	}
	private static boolean validateUser(String username,String password) throws WalletException{
		if(StaticDB.getWMap().size()!=0&&!StaticDB.getWMap().containsKey(username))
			{throw new WalletException("Username incorrect,No such account exist");}
		else if(!StaticDB.getWMap().get(username).getPassword().equals(password))
			{throw new WalletException("Wrong Password!! Access Denied");}
		else
			return true;
	}
}

