package com.cg.skwallet.db;
import java.time.LocalDateTime;
import java.util.*;

import com.cg.skwallet.bean.WalletAccount;
import com.cg.skwallet.bean.WalletTransaction;
public class StaticDB {
	private static HashMap<String, WalletAccount> wMap=new HashMap<String, WalletAccount>();
	private static HashMap<String, List<WalletTransaction>> tMap=new HashMap<String,List<WalletTransaction>>();
	
	static
	{
		wMap.put("User1",new WalletAccount("SK1",0,"sk@1"));
		wMap.put("User2",new WalletAccount("SK2",0,"sk@2"));
		tMap.put("User1",new ArrayList<WalletTransaction>());
		tMap.put("User2",new ArrayList<WalletTransaction>());
		tMap.get("User1").add(new WalletTransaction("User1", "Deposit",1000.0 , 1000,LocalDateTime.now()));
		wMap.get("User1").setBalance(1000);
		tMap.get("User1").add(new WalletTransaction("User1", "Withdraw",500 , 500,LocalDateTime.now() ));
		wMap.get("User1").setBalance(500);
		tMap.get("User1").add(new WalletTransaction("User1", "Transfer(debit)",250 , 250,LocalDateTime.now() ));
		tMap.get("User2").add(new WalletTransaction("User2", "Transfer(credit)",250 , 250,LocalDateTime.now() ));
		wMap.get("User1").setBalance(250);
		wMap.get("User2").setBalance(250);
	}
	public static HashMap<String, WalletAccount> getWMap()
	{
		return wMap;
	}
	
	public static HashMap<String,List<WalletTransaction>> getTMap()
	{  //System.out.println(tMap);
		return tMap;
	}

}
