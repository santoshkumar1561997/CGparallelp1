package com.cg.skwallet.bean;

import java.time.LocalDateTime;
import java.util.Date;

public class WalletTransaction {
	private String userName;
	private String type;
	private double amount;
	private double fbalance;
	private LocalDateTime d;
	public WalletTransaction(String userName, String type, double amount,
			double fbalance,LocalDateTime localDateTime) {
		super();
		this.userName = userName;
		this.type = type;
		this.amount = amount;
		this.fbalance = fbalance;
		this.d=localDateTime;
	}
	@Override
	public String toString() {
		return "\nWalletTransaction [userName=" + userName + ", type=" + type
				+ ", amount=" + amount + ", Final balance=" + fbalance + ", Date=" + d
				+ "]";
	}
	
		
	

}
