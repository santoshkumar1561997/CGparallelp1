package com.cg.skwallet.dao;

import com.cg.skwallet.bean.WalletAccount;
import com.cg.skwallet.bean.WalletTransaction;
import com.cg.skwallet.exception.WalletException;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDateTime;
import java.time.ZonedDateTime;
import java.util.*;

public class WalletDAOImpl implements WalletDAO{
private Connection con;
private PreparedStatement pst;
private Statement st;
private void makeConnection() {
try{	
	Class.forName("oracle.jdbc.driver.OracleDriver");
		con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE","hr","hr"); 
		System.out.println("Connected");
}		
catch(Exception e){
	e.printStackTrace();
}
}
private void releaseConnection() {
try{
	con.close();
}
catch(SQLException e) {
System.out.println(e);
}
}

	@Override
	public WalletAccount createAccount(WalletAccount acc) throws WalletException {
	
		boolean status=false;
		try{
			makeConnection();
			con.setAutoCommit(false);
			st = con.createStatement();
			ResultSet rs=st.executeQuery("select * from wallet");
			boolean isThere=false;
			while(rs.next()){
				if(rs.getString(1).equals(acc.getUserName())){
					isThere = true;
					break;
				}
			}
			if(isThere)
				throw new WalletException("Username already exists");
			pst=con.prepareStatement("Insert into Wallet values(?,?,?)");
			pst.setString(1, acc.getUserName());
			pst.setString(2, acc.getPassword());
			pst.setDouble(3, acc.getBalance());
			pst.executeUpdate();
			con.commit();
			status=true;
			addTransaction(acc.getUserName(),"Created",acc.getBalance(),acc.getBalance());
			return acc;
		}
		catch(SQLException e){
			status=false;
			try {
				con.rollback();
			} catch (SQLException e1) {
				// TODO: handle exception
				e1.printStackTrace();
			}
		}
		finally{
			releaseConnection();
		}
		return null;
	}

	@Override
	public double showBalance(String username,String password)  throws WalletException {
		// TODO Auto-generated method stub
		double d=0;
		try{
			makeConnection();
			con.setAutoCommit(false);
			st = con.createStatement();
			ResultSet rs=st.executeQuery("select * from wallet");
			boolean isThere=false;
			
			while(rs.next()){
				if(rs.getString(1).equals(username)){
					{isThere = true;d=rs.getDouble(3);
					}
					break;
				}
			}
			if(!isThere)
				throw new WalletException("Username or Password Invalid");
			}
		catch(SQLException e){
			try {
				con.rollback();
			} catch (SQLException e1) {
				// TODO: handle exception
				e1.printStackTrace();
			}
		}
		finally{
			releaseConnection();
		}
		return d;
		
	}
	@Override
	public WalletAccount deposit(String username, double amount) throws WalletException  {
		// TODO Auto-generated method stub
		boolean status=false;
		double d=0,dt=0;
		WalletAccount wa=new WalletAccount();
		try{
			makeConnection();
			con.setAutoCommit(false);
			st = con.createStatement();
			ResultSet rs=st.executeQuery("select * from wallet");
			boolean isThere=false;
			
			while(rs.next()){
				if(rs.getString(1).equals(username)){
					{isThere = true;
					dt=(double)rs.getDouble(3);
					 d=dt+amount;
					}
					break;
				}
			}
			
			if(!isThere)
				throw new WalletException("Username Invalid");
			
			pst=con.prepareStatement("Update wallet set balance=? where username=? ");
			pst.setDouble(1,d);
			pst.setString(2,username);
			pst.executeUpdate();
			con.commit();
			addTransaction(username,"Added",amount,d);
			
			}
		catch(SQLException e){
			status=false;
			try {
				con.rollback();
			} catch (SQLException e1) {
				// TODO: handle exception
				e1.printStackTrace();
			}
		}
		finally{
			releaseConnection();
			}
		wa.setUserName(username);
		wa.setBalance(d);
		return wa;
	}

	@Override
	public WalletAccount withdraw(String username,String password, double amount)  throws WalletException {
		// TODO Auto-generated method stub
		WalletAccount wa=new WalletAccount();
		boolean status=false;
		double d=0,dt=0;
		try{
			makeConnection();
			con.setAutoCommit(false);
			st = con.createStatement();
			ResultSet rs=st.executeQuery("select * from wallet");
			boolean isThere=false;
			
			while(rs.next()){
				if(rs.getString(1).equals(username)&&rs.getString(2).equals(password)){
					{isThere = true;
					dt=(double)rs.getDouble(3);
					 d=dt-amount;
					 if(d<=0) throw new WalletException("Insufficient balance");
					}
					break;
				}
			}
			
			if(!isThere)
				throw new WalletException("Username or password Invalid ");
			
			pst=con.prepareStatement("Update Wallet set balance=? where username=? and password=?");
			pst.setDouble(1,d);
			pst.setString(2,username);
			pst.setString(3,password);
			pst.executeUpdate();
			addTransaction(username,"Withdraw",amount,d);
			}
		catch(SQLException e){
			status=false;
			try {
				con.rollback();
			} catch (SQLException e1) {
				// TODO: handle exception
				//e1.printStackTrace();
				System.out.println(e1.getMessage());
			}
		}
		finally{
			releaseConnection();
			}
		wa.setUserName(username);
		wa.setBalance(d);
		return wa;
	}

	@Override
	public boolean fundTransfer(String fromUserName,String fromPassword,String toUserName,double amount) throws WalletException  {
		// TODO Auto-generated method stub
		boolean status=false;
		double da=0,dd=0;
		try{
			makeConnection();
		con.setAutoCommit(false);
		st = con.createStatement();
		ResultSet rs=st.executeQuery("select * from wallet");
		boolean isThere=false,recieveE=false;
		//From account 
		while(rs.next()){
			if(rs.getString(1).equals(fromUserName)&&rs.getString(2).equals(fromPassword)){
				{ isThere = true;
					Double dt=rs.getDouble(3);
					dd=dt-amount;
				
				 if(dd<=0) throw new WalletException("Insufficient balance");
				 	break;  }
			}
		}
		rs=st.executeQuery("select * from wallet");
		while(rs.next()){
			if(rs.getString(1).equals(toUserName)){
				recieveE=true;
				Double dt=rs.getDouble(3);
				da=dt+amount;
				break;
			}
		}
		if(!isThere)
			throw new WalletException("Username or password Invalid ");
		if(!recieveE)
			throw new WalletException("Receiver Doesnot Exists ");
		
		pst=con.prepareStatement("Update Wallet set balance=? where username=? and password=?");
		pst.setDouble(1,dd);
		pst.setString(2,fromUserName);
		pst.setString(3,fromPassword);
		pst.executeUpdate();
		
		//to account
		pst=con.prepareStatement("Update Wallet set balance=? where username=?");
		pst.setDouble(1,da);
		pst.setString(2,toUserName);
		pst.executeUpdate();
		status=true;
		addTransaction(fromUserName,"Transfer by you",amount,dd);
		addTransaction(toUserName,"Transfer to you",amount,da);
		}
		catch(SQLException e){
			status=false;
			try {
				con.rollback();
			} catch (SQLException e1) {
				// TODO: handle exception
				System.out.println(e1.getMessage());
			}
		}
		finally{
			releaseConnection();
		}
		return status;
	
	}

	@Override
	public ResultSet printTransactions(String username,String password) throws WalletException  {
		
		try {
			makeConnection();
			st = con.createStatement();
			ResultSet rs=st.executeQuery("select * from transaction where username='"+username+"'") ;
			/*while (rs.next()) {
				String Data = rs.getString(1) + " : " + rs.getString(2) + " : " + rs.getDouble(3) + " : " + rs.getDouble(4)+
						rs.getString(5);
				System.out.println(Data);
			}*/
			return rs;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;

		
	}
	private void addTransaction(String username,String type,double amount,double fbalance) {
		try{
		LocalDateTime d = LocalDateTime.now();
		pst=con.prepareStatement("Insert into Transaction values(?,?,?,?,?)");
		pst.setString(1,username);
		pst.setString(2,type);
		pst.setDouble(3,(Double)amount);
		pst.setDouble(4,(Double)fbalance);
		pst.setString(5," "+ d.getDayOfMonth()+" "+d.getMonth()+" "+d.getYear()+" "+d.getHour()+":"+d.getMinute()+":"+d.getSecond());
		pst.executeUpdate();
		con.commit();
			
	}catch(Exception e)
		{
	System.out.println(e.getMessage());
		}
	}
}

