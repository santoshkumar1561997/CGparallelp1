package com.cg.skwallet.dao;

import com.cg.skwallet.bean.WalletAccount;
import com.cg.skwallet.bean.WalletTransaction;
import com.cg.skwallet.exception.WalletException;

import java.sql.ResultSet;
import java.util.*;

public interface WalletDAO {
	public WalletAccount createAccount(WalletAccount acc)throws WalletException ;
	public double showBalance(String username,String password)throws WalletException ;
	public WalletAccount deposit(String username,double amount)throws WalletException ;
	public WalletAccount withdraw(String username,String password,double amount)throws WalletException ;
	public boolean fundTransfer(String fromUserName,String fromPassword,String toUserName,double amount)throws WalletException;
	public ResultSet printTransactions(String username,String password)throws WalletException ;

}
